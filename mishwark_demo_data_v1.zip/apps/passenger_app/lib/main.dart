import 'package:flutter/material.dart';
import 'screens/map_picker_screen.dart';
import 'screens/trip_flow_screen.dart';
import 'services/auth_service.dart';
import 'services/push_notification_service.dart';
import 'services/trip_service.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() => runApp(const MishwarkPassengerApp());

class MishwarkPassengerApp extends StatelessWidget {
  const MishwarkPassengerApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'مشوارك',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal),
    home: const PassengerHome(),
  );
}

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override State<PassengerHome> createState() => _PassengerHomeState();
}

class _PassengerHomeState extends State<PassengerHome> {
  static const api = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:3000');
  static const demoMode = true;
  final phone = TextEditingController();
  final otp = TextEditingController();
  String? token;
  String? tripId;
  LatLng? pickup;
  LatLng? destination;
  bool loading = false;
  String message = '';

  final List<Map<String, dynamic>> demoDrivers = [
    {'name': 'محمد أحمد', 'car': 'هيونداي إلنترا', 'plate': 'د م ن 4587', 'rating': 4.9, 'trips': 328, 'distance': '1.2 كم'},
    {'name': 'أحمد محمود', 'car': 'كيا سيراتو', 'plate': 'ر س أ 2145', 'rating': 4.8, 'trips': 214, 'distance': '2.1 كم'},
    {'name': 'محمود علي', 'car': 'تويوتا كورولا', 'plate': 'ق ع ب 9031', 'rating': 4.7, 'trips': 176, 'distance': '2.8 كم'},
  ];

  Future<void> auth() async {
    setState(() => loading = true);
    try {
      if (token == null) {
        if (demoMode) {
          otp.text = '123456';
          setState(() => message = 'وضع الاختبار: الرمز 123456 جاهز');
        } else {
          final r = await AuthService(api).requestOtp(phone.text.trim());
          if (!mounted) return;
          otp.text = r['devCode']?.toString() ?? '';
          setState(() => message = 'تم إرسال الرمز');
        }
      }
    } catch (e) {
      if (mounted) setState(() => message = e.toString());
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> verify() async {
    setState(() => loading = true);
    try {
      if (demoMode) {
        if (otp.text.trim() != '123456') throw Exception('رمز الاختبار يجب أن يكون 123456');
        token = 'demo-passenger-token';
        setState(() => message = 'تم تسجيل الدخول — البيانات التجريبية جاهزة');
      } else {
        final d = await AuthService(api).verifyOtp(phone: phone.text.trim(), code: otp.text.trim(), role: 'PASSENGER');
        token = d['token'];
        await PushNotificationService(baseUrl: api, token: token!).init();
        setState(() => message = 'تم تسجيل الدخول');
      }
    } catch (e) {
      if (mounted) setState(() => message = e.toString());
    } finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> locate() async {
    // في وضع البيانات التجريبية لا نحتاج GPS حتى تعمل التجربة فوراً.
    if (demoMode) {
      setState(() => pickup = const LatLng(30.0444, 31.2357));
      return;
    }
  }

  Future<void> chooseDestination() async {
    if (demoMode) {
      setState(() => destination = const LatLng(30.0626, 31.2497));
      return;
    }
    final d = await Navigator.push<LatLng>(context, MaterialPageRoute(builder: (_) => MapPickerScreen(initialPickup: pickup)));
    if (d != null) setState(() => destination = d);
  }

  Future<void> requestTrip() async {
    if (token == null || pickup == null || destination == null) return;
    if (demoMode) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => TripFlowScreen(
        tripId: 'DEMO-2026-001', token: token!, baseUrl: api,
      )));
      return;
    }
    setState(() => loading = true);
    try {
      final t = await TripService(api, token!).createTrip(
        pickupLat: pickup!.latitude, pickupLng: pickup!.longitude,
        destinationLat: destination!.latitude, destinationLng: destination!.longitude,
      );
      tripId = t['id'];
      if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => TripFlowScreen(tripId: tripId!, token: token!, baseUrl: api)));
    } catch (e) { if (mounted) setState(() => message = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  Widget driverCard(Map<String, dynamic> d) => Card(
    child: ListTile(
      leading: CircleAvatar(child: Text(d['name'].toString().substring(0, 1))),
      title: Text(d['name']),
      subtitle: Text('${d['car']} • ${d['plate']}\n⭐ ${d['rating']}  •  ${d['trips']} رحلة  •  ${d['distance']}'),
      isThreeLine: true,
    ),
  );

  Widget demoData() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    const Text('السائقون المتاحون', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    ...demoDrivers.map(driverCard),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: const [
      Text('رحلة تجريبية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('القاهرة → مدينة نصر'),
      Text('السعر التقريبي: 85 جنيه'),
      Text('المسافة: 8.4 كم  •  الزمن: 24 دقيقة'),
    ]))),
  ]);

  @override
  Widget build(BuildContext c) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('مشوارك — الراكب')),
      body: Padding(padding: const EdgeInsets.all(18), child: ListView(children: [
        if (token == null) ...[
          const Text('تسجيل الدخول', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: otp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رمز التحقق (وضع الاختبار)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          Row(children: [Expanded(child: FilledButton(onPressed: loading ? null : auth, child: const Text('طلب الرمز'))), const SizedBox(width: 8), Expanded(child: FilledButton(onPressed: loading ? null : verify, child: const Text('تسجيل الدخول')))]),
        ] else ...[
          demoData(),
          const SizedBox(height: 16),
          FilledButton(onPressed: locate, child: Text(pickup == null ? 'تحديد نقطة الانطلاق' : '✓ القاهرة — نقطة الانطلاق')),
          FilledButton(onPressed: chooseDestination, child: Text(destination == null ? 'اختيار الوجهة' : '✓ مدينة نصر — الوجهة')),
          if (pickup != null && destination != null) FilledButton(onPressed: loading ? null : requestTrip, child: const Text('🚕 اطلب مشوارك التجريبي')),
        ],
        const SizedBox(height: 15),
        if (message.isNotEmpty) Text(message),
      ])),
    ),
  );
}
