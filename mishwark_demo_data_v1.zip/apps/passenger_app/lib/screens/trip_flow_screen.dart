import 'dart:async';
import 'package:flutter/material.dart';
import '../services/trip_actions_service.dart';

class TripFlowScreen extends StatefulWidget {
  final String tripId;
  final String token;
  final String baseUrl;
  const TripFlowScreen({super.key, required this.tripId, required this.token, required this.baseUrl});
  @override State<TripFlowScreen> createState() => _TripFlowScreenState();
}

class _TripFlowScreenState extends State<TripFlowScreen> {
  late final TripActionsService api;
  Timer? timer;
  int demoStep = 0;
  final statuses = const ['SEARCHING_DRIVER','DRIVER_ACCEPTED','DRIVER_ARRIVING','DRIVER_ARRIVED','TRIP_STARTED','TRIP_COMPLETED','COMPLETED'];
  final labels = const {
    'SEARCHING_DRIVER':'جاري البحث عن سائق', 'DRIVER_ACCEPTED':'السائق قبل الرحلة', 'DRIVER_ARRIVING':'السائق في الطريق إليك',
    'DRIVER_ARRIVED':'السائق وصل', 'TRIP_STARTED':'الرحلة جارية الآن', 'TRIP_COMPLETED':'وصلت إلى الوجهة', 'COMPLETED':'اكتملت الرحلة'
  };
  bool get demo => widget.token == 'demo-passenger-token';
  String get status => statuses[demoStep];

  @override void initState() {
    super.initState();
    api = TripActionsService(baseUrl: widget.baseUrl, token: widget.token);
    if (demo) {
      timer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (!mounted || demoStep >= statuses.length - 1) return;
        setState(() => demoStep++);
      });
    }
  }

  @override void dispose() { timer?.cancel(); super.dispose(); }

  Widget info(String title, String value, IconData icon) => Card(child: ListTile(leading: CircleAvatar(child: Icon(icon)), title: Text(title), subtitle: Text(value)));

  @override Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('رحلتي')),
      body: Padding(padding: const EdgeInsets.all(18), child: ListView(children: [
        Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(children: [
          const Icon(Icons.local_taxi, size: 54), const SizedBox(height: 10),
          Text(labels[status]!, style: Theme.of(context).textTheme.headlineSmall, textAlign: TextAlign.center),
          const SizedBox(height: 8), Text('رقم الرحلة: ${widget.tripId}'),
        ]))),
        info('السائق', 'محمد أحمد', Icons.person),
        info('السيارة', 'هيونداي إلنترا • د م ن 4587', Icons.directions_car),
        info('التقييم', '⭐ 4.9 / 5  •  328 رحلة', Icons.star),
        info('المسار', 'القاهرة → مدينة نصر', Icons.route),
        info('السعر', '85 جنيه', Icons.payments),
        if (status == 'TRIP_COMPLETED') FilledButton(onPressed: () {
          if (demo) setState(() => demoStep = statuses.indexOf('COMPLETED'));
          else api.cashPayment(widget.tripId);
        }, child: const Text('تم الدفع نقدًا')),
        if (status == 'COMPLETED') ...[
          const SizedBox(height: 12), const Text('شكراً لاستخدام مشوارك ❤️', textAlign: TextAlign.center),
          const SizedBox(height: 8), FilledButton(onPressed: () {}, child: const Text('⭐ تقييم السائق 5 نجوم')),
        ],
        if (demo) const Padding(padding: EdgeInsets.only(top: 18), child: Text('وضع تجريبي: الحالة تتغير تلقائياً كل 5 ثوانٍ', textAlign: TextAlign.center)),
      ])),
    ),
  );
}
