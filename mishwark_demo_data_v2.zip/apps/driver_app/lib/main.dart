import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'services/auth_service.dart';
import 'services/push_notification_service.dart';
import 'services/trip_actions_service.dart';

void main() => runApp(const MishwarkDriverApp());

class MishwarkDriverApp extends StatelessWidget {
  const MishwarkDriverApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'مشوارك — السائق',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal),
    home: const DriverHome(),
  );
}

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  static const api = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:3000');
  static const demoMode = true;
  final phone = TextEditingController();
  final otp = TextEditingController();
  String? token;
  bool online = false, loading = false;
  Map<String, dynamic>? trip;
  Timer? timer;

  final demoTrip = <String, dynamic>{
    'id': 'DEMO-2026-001',
    'status': 'SEARCHING_DRIVER',
    'passenger': 'أحمد طه',
    'pickup': 'قويسنا',
    'destination': 'شبين الكوم',
    'price': 95,
    'distance': '18.5 كم',
    'eta': '28 دقيقة',
  };

  Future<Position?> pos() async {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.denied || p == LocationPermission.deniedForever) return null;
    return Geolocator.getCurrentPosition();
  }

  Future<void> requestOtp() async {
    setState(() => loading = true);
    try {
      if (demoMode) {
        otp.text = '123456';
      } else {
        final r = await AuthService(api).requestOtp(phone.text.trim());
        otp.text = r['devCode']?.toString() ?? '';
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> login() async {
    setState(() => loading = true);
    try {
      if (demoMode) {
        if (otp.text.trim() != '123456') throw Exception('رمز الاختبار يجب أن يكون 123456');
        token = 'demo-driver-token';
        trip = Map<String, dynamic>.from(demoTrip);
      } else {
        final d = await AuthService(api).verifyOtp(phone: phone.text.trim(), code: otp.text.trim(), role: 'DRIVER');
        token = d['token'];
        await PushNotificationService(baseUrl: api, token: token!).init();
      }
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> toggle() async {
    if (demoMode) {
      setState(() => online = !online);
      if (online) {
        timer ??= Timer.periodic(const Duration(seconds: 5), (_) {});
      } else {
        timer?.cancel();
        timer = null;
      }
      return;
    }
    final p = await pos();
    if (p == null) return;
    final r = await http.post(Uri.parse('$api/drivers/me/online'), headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'}, body: jsonEncode({'online': !online, 'lat': p.latitude, 'lng': p.longitude}));
    if (r.statusCode == 200) {
      setState(() => online = !online);
      if (online) timer = Timer.periodic(const Duration(seconds: 5), (_) => poll()); else timer?.cancel();
    }
  }

  Future<void> poll() async {
    if (!online || demoMode) return;
    final p = await pos();
    if (p != null) await http.post(Uri.parse('$api/drivers/me/location'), headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'}, body: jsonEncode({'lat': p.latitude, 'lng': p.longitude}));
    final r = await http.get(Uri.parse('$api/drivers/me/trip'), headers: {'Authorization': 'Bearer $token'});
    if (r.statusCode == 200 && mounted) setState(() => trip = jsonDecode(r.body)['trip']);
  }

  Future<void> action(String a) async {
    if (trip == null) return;
    if (demoMode) {
      const next = {
        'ACCEPT': 'DRIVER_ACCEPTED',
        'ARRIVING': 'DRIVER_ARRIVING',
        'ARRIVED': 'DRIVER_ARRIVED',
        'START': 'TRIP_STARTED',
        'COMPLETE': 'TRIP_COMPLETED',
      };
      final status = next[a];
      if (status != null) setState(() => trip!['status'] = status);
      return;
    }
    final api2 = TripActionsService(baseUrl: api, token: token!);
    try { await api2.action(trip!['id'], a); await poll(); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
  }

  @override void dispose() { timer?.cancel(); phone.dispose(); otp.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext c) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('مشوارك — السائق')),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: token == null
          ? Column(children: [
              const Text('تسجيل دخول السائق', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              TextField(controller: phone, decoration: const InputDecoration(labelText: 'رقم الهاتف', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              TextField(controller: otp, decoration: const InputDecoration(labelText: 'رمز التحقق (123456)', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              Row(children: [Expanded(child: FilledButton(onPressed: loading ? null : requestOtp, child: const Text('طلب الرمز'))), const SizedBox(width: 8), Expanded(child: FilledButton(onPressed: loading ? null : login, child: const Text('دخول')))]),
            ])
          : ListView(children: [
              SwitchListTile(title: Text(online ? 'متصل الآن' : 'غير متصل'), subtitle: const Text('وضع البيانات التجريبية'), value: online, onChanged: (_) => toggle()),
              const SizedBox(height: 10),
              if (trip == null) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('لا توجد رحلة مخصصة لك الآن')))
              else Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('رحلة تجريبية مخصصة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                Text('رقم الرحلة: ${trip!['id']}'),
                Text('الراكب: ${trip!['passenger']}'),
                Text('من: ${trip!['pickup']}'),
                Text('إلى: ${trip!['destination']}'),
                Text('السعر: ${trip!['price']} جنيه'),
                Text('المسافة: ${trip!['distance']} • ${trip!['eta']}'),
                const SizedBox(height: 8),
                Text('الحالة: ${trip!['status']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                if (trip!['status'] == 'SEARCHING_DRIVER') FilledButton(onPressed: () => action('ACCEPT'), child: const Text('قبول الرحلة')),
                if (trip!['status'] == 'DRIVER_ACCEPTED') FilledButton(onPressed: () => action('ARRIVING'), child: const Text('أنا في الطريق')),
                if (trip!['status'] == 'DRIVER_ARRIVING') FilledButton(onPressed: () => action('ARRIVED'), child: const Text('وصلت')),
                if (trip!['status'] == 'DRIVER_ARRIVED') FilledButton(onPressed: () => action('START'), child: const Text('بدء الرحلة')),
                if (trip!['status'] == 'TRIP_STARTED') FilledButton(onPressed: () => action('COMPLETE'), child: const Text('إنهاء الرحلة')),
                if (trip!['status'] == 'TRIP_COMPLETED') const Text('تم إنهاء الرحلة التجريبية — بانتظار الدفع', style: TextStyle(fontWeight: FontWeight.bold)),
              ]))),
            ]),
      ),
    ),
  );
}
