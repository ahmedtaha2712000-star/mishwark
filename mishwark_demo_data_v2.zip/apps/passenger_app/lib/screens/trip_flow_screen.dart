import 'dart:async';
import 'package:flutter/material.dart';
import '../services/trip_actions_service.dart';

class TripFlowScreen extends StatefulWidget {
  final String tripId;
  final String token;
  final String baseUrl;
  const TripFlowScreen({super.key, required this.tripId, required this.token, required this.baseUrl});
  @override State<TripFlowScreen> createState() => _TripFlowScreenState();
}

class _TripFlowScreenState extends State<TripFlowScreen> {
  late final TripActionsService api;
  String status = 'SEARCHING_DRIVER';
  Timer? timer;
  Map<String, dynamic>? trip;
  bool get demoMode => widget.token == 'demo-passenger-token';

  @override
  void initState() {
    super.initState();
    api = TripActionsService(baseUrl: widget.baseUrl, token: widget.token);
    if (demoMode) {
      trip = {
        'id': widget.tripId,
        'status': 'SEARCHING_DRIVER',
        'driver': 'محمد أحمد',
        'car': 'هيونداي إلنترا',
        'plate': 'د م ن 4587',
        'rating': 4.9,
        'pickup': 'القاهرة',
        'destination': 'مدينة نصر',
        'price': 85,
        'distance': '8.4 كم',
        'eta': '24 دقيقة',
      };
    } else {
      load();
      timer = Timer.periodic(const Duration(seconds: 4), (_) => load());
    }
  }

  Future<void> load() async {
    try {
      final x = await api.live(widget.tripId);
      if (mounted) setState(() { trip = x; status = x['status'] ?? status; });
    } catch (_) {}
  }

  Future<void> act(String action) async {
    if (demoMode) {
      const next = {'CANCEL':'CANCELLED','ACCEPT':'DRIVER_ACCEPTED','ARRIVING':'DRIVER_ARRIVING','ARRIVED':'DRIVER_ARRIVED','START':'TRIP_STARTED','COMPLETE':'TRIP_COMPLETED'};
      final s = next[action];
      if (s != null && mounted) setState(() { status = s; trip!['status'] = s; });
      return;
    }
    try {
      final x = await api.action(widget.tripId, action);
      if (mounted) setState(() => status = x['status'] ?? status);
      load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override void dispose() { timer?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('رحلتي التجريبية')),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: ListView(children: [
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('الحالة: $status', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            if (trip != null) ...[
              Text('السائق: ${trip!['driver']}'),
              Text('السيارة: ${trip!['car']} — ${trip!['plate']}'),
              Text('التقييم: ⭐ ${trip!['rating']}'),
              Text('المسار: ${trip!['pickup']} → ${trip!['destination']}'),
              Text('السعر: ${trip!['price']} جنيه'),
              Text('المسافة: ${trip!['distance']} • ${trip!['eta']}'),
            ],
          ]))),
          const SizedBox(height: 12),
          if (status == 'REQUESTED' || status == 'SEARCHING_DRIVER') FilledButton(onPressed: () => act('CANCEL'), child: const Text('إلغاء الرحلة')),
          if (status == 'SEARCHING_DRIVER') const Text('جارٍ البحث عن سائق متاح...'),
          if (status == 'DRIVER_ACCEPTED' || status == 'DRIVER_ARRIVING') const Text('السائق في الطريق إليك'),
          if (status == 'DRIVER_ARRIVED') const Text('السائق وصل إلى نقطة الالتقاط'),
          if (status == 'TRIP_STARTED') const Text('الرحلة جارية الآن'),
          if (status == 'TRIP_COMPLETED') ...[
            const Text('اكتملت الرحلة'),
            FilledButton(onPressed: () { if (demoMode) { setState(() { status = 'COMPLETED'; trip!['status'] = 'COMPLETED'; }); } else { api.cashPayment(widget.tripId); load(); } }, child: const Text('تم الدفع نقدًا')),
          ],
          if (status == 'COMPLETED') ...[
            const Text('تم الدفع — الرحلة مكتملة'),
            FilledButton(onPressed: () { if (demoMode) { setState(() => trip!['rated'] = true); } else { api.rate(widget.tripId, 5); } }, child: const Text('تقييم 5 نجوم')),
          ],
        ]),
      ),
    ),
  );
}
