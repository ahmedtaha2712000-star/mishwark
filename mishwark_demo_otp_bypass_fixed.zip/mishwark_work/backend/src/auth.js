const crypto=require('crypto');
const jwt=require('jsonwebtoken');
const {pool}=require('./db');
function normalizePhone(phone){return String(phone||'').trim().replace(/[^\d+]/g,'');}
function hashCode(code){return crypto.createHash('sha256').update(String(code)).digest('hex');}
async function requestOtp(phone){
  const normalized=normalizePhone(phone); if(!/^\+?\d{10,15}$/.test(normalized))throw new Error('Invalid phone number');
  const code=String(crypto.randomInt(100000,1000000));
  await pool.query(`INSERT INTO otp_codes(phone,code_hash,expires_at) VALUES($1,$2,now()+interval '5 minutes')`,[normalized,hashCode(code)]);
  if(process.env.NODE_ENV!=='production')return {phone:normalized,expiresInSeconds:300,devCode:code};
  console.log(`OTP created for ${normalized}; configure SMS provider before production.`);
  return {phone:normalized,expiresInSeconds:300};
}
async function verifyOtp(phone,code,role='PASSENGER'){
  const normalized=normalizePhone(phone); const {rows}=await pool.query(`SELECT * FROM otp_codes WHERE phone=$1 AND consumed_at IS NULL AND expires_at>now() ORDER BY created_at DESC LIMIT 1`,[normalized]);
  const otp=rows[0]; if(!otp)throw new Error('OTP expired or not found'); if(otp.attempts>=5)throw new Error('Too many attempts');
  await pool.query(`UPDATE otp_codes SET attempts=attempts+1 WHERE id=$1`,[otp.id]); if(hashCode(code)!==otp.code_hash)throw new Error('Invalid OTP');
  await pool.query(`UPDATE otp_codes SET consumed_at=now() WHERE id=$1`,[otp.id]);
  const safeRole=role==='DRIVER'?'DRIVER':'PASSENGER';
  const user=(await pool.query(`INSERT INTO users(phone,role) VALUES($1,$2) ON CONFLICT(phone) DO UPDATE SET role=CASE WHEN users.role='ADMIN' THEN users.role ELSE EXCLUDED.role END RETURNING *`,[normalized,safeRole])).rows[0];
  if(user.role==='DRIVER')await pool.query(`INSERT INTO drivers(user_id) VALUES($1) ON CONFLICT(user_id) DO NOTHING`,[user.id]);
  const secret=process.env.JWT_SECRET;if(!secret)throw new Error('JWT_SECRET is not configured');
  const token=jwt.sign({sub:user.id,role:user.role,phone:user.phone},secret,{expiresIn:process.env.JWT_EXPIRES_IN||'7d'});
  return {token,user};
}
function requireAuth(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return res.status(401).json({error:'Unauthorized'});req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET);next();}catch(e){res.status(401).json({error:'Invalid or expired token'});}}
function requireRole(...roles){return(req,res,next)=>{if(!req.user||!roles.includes(req.user.role))return res.status(403).json({error:'Forbidden'});next();};}
module.exports={requestOtp,verifyOtp,requireAuth,requireRole,normalizePhone};
