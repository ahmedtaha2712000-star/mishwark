# Mishwark Demo OTP Mode

Temporary testing mode.

1. Set `DEMO_MODE=true` on the backend.
2. Demo OTP is `123456`.
3. Passenger and driver apps auto-fill `123456` after requesting OTP.
4. Disable `DEMO_MODE` before production.
