# المرحلة الثانية — مشوارك

تمت إضافة:
- تطبيق سائق Flutter مستقل.
- Online/Offline للسائق.
- إرسال موقع السائق للـBackend.
- ظهور الرحلات المطلوبة للسائق.
- قبول الرحلة.
- حالات الرحلة الأساسية على الـAPI.
- API للاستعلام عن الرحلة.

## التشغيل

### Backend
cd backend
npm install
npm start

### Passenger
cd apps/passenger_app
flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:3000

### Driver
cd apps/driver_app
flutter pub get
flutter run --dart-define=API_URL=http://10.0.2.2:3000

## ملاحظة
الخريطة الحقيقية تحتاج Google Maps API Key. لم أضع أي مفتاح داخل المشروع.
اختيار الوجهة الحالي في تطبيق الراكب ما زال يحتاج ربط Google Maps/Places/Routes في الخطوة التالية.
