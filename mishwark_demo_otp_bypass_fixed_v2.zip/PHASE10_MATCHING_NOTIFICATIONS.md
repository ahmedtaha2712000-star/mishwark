# مشوارك — المرحلة العاشرة: اختيار السائق + الإشعارات

تمت إضافة:

## اختيار السائق
- البحث عن أقرب سائق Online باستخدام موقع الالتقاط.
- حساب المسافة الجغرافية.
- حد افتراضي 10 كم.
- تحويل السائق إلى BUSY بعد الإسناد.
- endpoint:
  `POST /trips/:id/match-driver`

## الإشعارات
تم تجهيز abstraction لـ Push Notifications.
في التطوير يتم تسجيل الإشعار في log.
في الإنتاج يجب ربط Firebase Admin SDK/FCM وApple Push Notification حسب المنصة.

## Flutter
- `MatchingService`
- `PushNotificationService`
- إضافة `firebase_messaging` كخطوة تجهيز.

## مهم
هذا Matching أولي. قبل الإنتاج يجب:
- إضافة PostGIS أو geospatial indexing للأعداد الكبيرة.
- نظام timeout وإعادة البحث عن سائق.
- منع تعارض إسناد سائق لرحلتين في نفس اللحظة باستخدام transaction/locking.
- إرسال Push حقيقي.
- تسجيل device tokens.
- التعامل مع السائقين الذين لا يردون.
