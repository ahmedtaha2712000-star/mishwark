# مشوارك — المرحلة 11: لوحة الإدارة

تمت إضافة لوحة Admin أولية وواجهات API محمية بدور ADMIN.

## API
- GET /admin/stats
- GET /admin/trips
- GET /admin/drivers
- GET /admin/users
- PATCH /admin/drivers/:id/status

## Dashboard
- إحصائيات المستخدمين والسائقين والرحلات والإيرادات.
- قائمة السائقين وحالاتهم ومواقعهم.
- آخر الرحلات.
- دخول بواسطة JWT.

## تشغيل لوحة الإدارة
داخل apps/admin_web:
npm install
npm run dev

ضع:
VITE_API_URL=http://localhost:3000

## ملاحظات الإنتاج
- إنشاء نظام Admin Login مستقل.
- MFA.
- صلاحيات متعددة RBAC.
- سجل تدقيق Audit Log.
- إدارة الأسعار والمناطق.
- إدارة المستندات والشكاوى.
- حماية API وCORS وrate limiting.
