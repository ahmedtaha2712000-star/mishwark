# مشوارك — المرحلة 12

تمت إضافة طبقة تشغيلية للوحة الإدارة:

- المدن والمناطق.
- قواعد الأسعار لكل مدينة.
- مستندات السائقين واعتمادها/رفضها.
- تذاكر الدعم والشكاوى.
- عرض الأسعار والمستندات والتذاكر في لوحة الإدارة.
- API محمية بدور ADMIN.

Endpoints:
- GET/POST /admin/cities
- GET/POST /admin/areas
- GET/POST /admin/pricing
- GET/PATCH /admin/documents
- GET/PATCH /admin/tickets

ملاحظة: رفع الملفات الحقيقي (S3/Cloud Storage) وتكامل SMS/Push ومراجعة المستندات آليًا لم تُفعّل بعد.
