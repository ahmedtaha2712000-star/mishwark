# مشوارك — المرحلة الثالثة: الخرائط والمسار

هذه المرحلة تجهز المشروع للخرائط الحقيقية مع الحفاظ على عمل الـMVP الحالي.

## المطلوب في Google Cloud
فعّل للمشروع:
- Maps SDK for Android
- Maps SDK for iOS
- Places API
- Routes API

لا تضع مفتاح Google الحقيقي داخل Git أو ترسله داخل المحادثة.

## Passenger App
سيتم إضافة:
- خريطة تفتح على موقع الراكب.
- Marker لموقع الانطلاق.
- اختيار الوجهة من الخريطة.
- Marker للوجهة.
- رسم المسار.
- عرض المسافة والوقت.
- إرسال pickup/destination إلى backend.

## Driver App
سيتم إضافة:
- خريطة موقع السائق.
- تحديث الموقع أثناء Online.
- عرض نقطة الراكب عند قبول الرحلة.
- عرض الوجهة والمسار.

## Backend
سيتم نقل حساب المسافة/الوقت إلى خدمة Routes API في طبقة مستقلة، ثم:
`distance + duration + pricing rules -> fare`

## الحالة الحالية
النسخة الحالية ما زالت Development MVP:
- التخزين في الذاكرة وليس PostgreSQL.
- المصادقة OTP غير مضافة.
- WebSocket/live location الكامل غير مضاف بعد.
- مفاتيح Google غير مضافة.

## ترتيب التنفيذ
1. Maps SDK + current location
2. destination picker
3. Routes API
4. fare calculation
5. live driver tracking عبر WebSocket
6. PostgreSQL
7. OTP/auth
8. admin dashboard
