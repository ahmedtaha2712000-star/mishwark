# مشوارك — المرحلة الرابعة: واجهة الخرائط

تمت إضافة `MapPickerScreen` لتطبيق الراكب.

## الاستخدام
يمكن فتح الشاشة هكذا:

```dart
final destination = await Navigator.push(
  context,
  MaterialPageRoute(
    builder: (_) => MapPickerScreen(
      initialPickup: pickup,
    ),
  ),
);
```

ثم إرسال `destination.latitude` و`destination.longitude` إلى backend.

## Android
ضع مفتاح Google Maps في `android/app/src/main/AndroidManifest.xml` كـ metadata
عبر متغير build/secret، وليس كنص ثابت داخل Git.

## iOS
أضف مفتاح Google Maps إلى إعدادات iOS عبر `GMSServices.provideAPIKey`
باستخدام إعداد سري محلي.

## ملاحظات
- الشاشة الحالية تختار الوجهة بالنقر على الخريطة.
- حساب الطريق الحقيقي (Routes API) لم يُضمَّن بعد.
- السعر الحقيقي يجب أن يعتمد على distance/duration القادمة من backend.
- Cairo مستخدمة فقط كنقطة افتراضية عند عدم توفر موقع حالي.
