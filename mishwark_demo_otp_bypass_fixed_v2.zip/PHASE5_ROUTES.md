# مشوارك — المرحلة الخامسة: Routes + التسعير

تمت إضافة:
- Backend endpoint: `POST /routes/estimate`
- تكامل Google Routes API عند توفر `GOOGLE_ROUTES_API_KEY`
- إرجاع distance / duration / encoded polyline
- حساب أجرة تقديرية بالجنيه المصري من قواعد قابلة للتعديل
- Flutter `RoutesService` لاستدعاء endpoint

## مثال الطلب
```json
{
  "origin": {"lat": 30.0444, "lng": 31.2357},
  "destination": {"lat": 30.0131, "lng": 31.2089}
}
```

## مثال النتيجة
```json
{
  "provider": "google",
  "distanceMeters": 12345,
  "durationSeconds": 1800,
  "polyline": "...",
  "estimatedFare": 175,
  "currency": "EGP"
}
```

## مهم
- الأرقام الافتراضية للتسعير تجريبية وليست تسعيرة تجارية نهائية.
- مفتاح Routes API يجب أن يبقى على الخادم، وليس داخل تطبيق Flutter.
- عند عدم وجود المفتاح، endpoint يرجع وضع `demo` ولا يدّعي وجود مسار حقيقي.
- قبل الإنتاج يجب إضافة حدود للمعدل، تسجيل الأخطاء، التحقق من المدخلات، ومفاتيح Google مقيدة.
