# مشوارك — المرحلة السادسة: التتبع اللحظي

تمت إضافة WebSocket development layer.

## الاتصال
`ws://YOUR_SERVER/ws?tripId=TRIP_ID&role=passenger`

أو للسائق:
`ws://YOUR_SERVER/ws?tripId=TRIP_ID&role=driver`

## رسائل الموقع
السائق يرسل:
```json
{"type":"driver_location","lat":30.04,"lng":31.23}
```

الراكب يستقبل:
```json
{
  "type":"driver_location",
  "tripId":"123",
  "lat":30.04,
  "lng":31.23,
  "timestamp":1730000000000
}
```

## رسائل الحالة
```json
{"type":"trip_status","status":"DRIVER_ARRIVING"}
```

## ملاحظات الإنتاج
هذه طبقة realtime أولية للتطوير. قبل الإطلاق يجب إضافة:
- مصادقة WebSocket.
- التحقق من أن السائق مرتبط فعلاً بالرحلة.
- Redis Pub/Sub عند تشغيل أكثر من instance.
- throttling لمواقع GPS.
- HTTPS/WSS.
- حفظ المواقع المهمة في PostgreSQL.
