# مشوارك — المرحلة السابعة: PostgreSQL + Live Map

تمت إضافة:

## قاعدة البيانات
- users
- drivers
- trips
- فهارس للحالات والسائقين
- PostgreSQL repository functions

تشغيل المخطط:
`psql "$DATABASE_URL" -f backend/sql/schema.sql`

## Backend
- `pg` connection pool
- repository لإنشاء الرحلات وتعيين السائق وتغيير الحالة وتحديث موقع السائق
- `.env.postgres.example`

## Flutter
تمت إضافة `LiveDriverMap` لعرض Marker للسائق ويتحرك مع رسائل WebSocket.

## مهم
هذه ما زالت نسخة تطوير:
- يجب ربط الـrepository فعلياً بكل endpoints قبل الإنتاج.
- يجب إضافة migrations بدلاً من تشغيل schema مباشرة في بيئة الإنتاج.
- يجب إضافة Authentication/Authorization.
- يجب حماية WebSocket والتحقق من ملكية الرحلة.
- لا تستخدم بيانات الاعتماد الموجودة في أمثلة البيئة كما هي.
