# مشوارك — المرحلة الثامنة: تسجيل الدخول وOTP

تمت إضافة:
- `POST /auth/request-otp`
- `POST /auth/verify-otp`
- JWT access token
- `GET /auth/me`
- حماية endpoints عبر `requireAuth`
- صلاحيات `requireRole`
- تخزين OTP كـ hash مع انتهاء 5 دقائق وحد أقصى للمحاولات
- Flutter AuthService مع حفظ token محلياً

## وضع التطوير
في `NODE_ENV=development` يعيد endpoint طلب OTP قيمة `devCode` لتسهيل الاختبار.

**لا تفعل ذلك في الإنتاج.**

## الإنتاج
قبل إطلاق التطبيق:
- اربط مزود SMS حقيقي.
- لا ترجع OTP من API.
- استخدم JWT_SECRET عشوائياً وقوياً.
- أضف rate limiting حسب الهاتف وIP.
- أضف device/session management.
- أضف KYC/مراجعة مستندات السائق قبل تفعيل دور DRIVER.
- اربط كل endpoints المهمة بـ`requireAuth` و`requireRole`.
