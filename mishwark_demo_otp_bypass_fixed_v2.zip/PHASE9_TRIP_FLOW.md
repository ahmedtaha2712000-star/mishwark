# مشوارك — المرحلة التاسعة: دورة الرحلة الكاملة

تمت إضافة أساس دورة الرحلة:

REQUESTED
→ SEARCHING_DRIVER
→ DRIVER_ACCEPTED
→ DRIVER_ARRIVING
→ DRIVER_ARRIVED
→ TRIP_STARTED
→ TRIP_COMPLETED
→ PAYMENT_PENDING
→ COMPLETED

كما أضيف:
- رفض الانتقالات غير المسموح بها.
- دفع نقدي.
- تقييم من 1 إلى 5.
- سجل تقييمات.
- API لقراءة الرحلة الحية.
- Flutter TripFlowService.

## مهم
هذه نسخة تطوير. ما زال يجب:
- ربط كل الانتقالات بهوية الراكب/السائق والرحلة بدقة.
- تسجيل كل transition في `trip_status_history`.
- اختيار السائق تلقائياً.
- إضافة إلغاء بسياسات ورسوم إن لزم.
- إضافة شاشة UI كاملة لكل حالة.
- إضافة إشعارات Push.
