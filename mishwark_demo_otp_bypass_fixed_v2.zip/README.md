# مشوارك (Mishwark) — Release Candidate 1.0

هذا الإصدار يجمع مراحل المشروع السابقة في حزمة واحدة: تطبيق الراكب، تطبيق السائق، لوحة الإدارة، API، PostgreSQL، الخرائط، التسعير، المطابقة، التتبع اللحظي، OTP، الإشعارات، الدفع النقدي، التقييم، الدعم ومستندات السائقين.

## ما تم تنفيذه
- تسجيل الراكب والسائق برقم الهاتف وOTP.
- JWT وحماية API حسب الدور.
- إنشاء الرحلة وحساب الأجرة.
- Google Routes API مع fallback للتطوير.
- البحث عن أقرب سائق وحجزه.
- حالات الرحلة الكاملة حتى الدفع النقدي والتقييم.
- PostgreSQL مع سجل حالات الرحلة.
- WebSocket آمن بالـ JWT لتتبع السائق.
- Firebase Cloud Messaging عندما تضاف بيانات Firebase.
- لوحة إدارة وتسجيل دخول مستقل.
- المدن والمناطق والأسعار والمستندات والدعم.
- Docker Compose لتشغيل API وPostgreSQL.
- Rate limiting وHelmet وCORS.

## تشغيل سريع للتطوير
1. ثبّت Node.js 22 وDocker.
2. انسخ `backend/.env.production.example` إلى `backend/.env.production` وعدّل القيم.
3. غيّر `POSTGRES_PASSWORD` في ملف البيئة أو عند تشغيل Docker Compose.
4. نفّذ:
   `docker compose up --build`
5. اختبر:
   `http://localhost:3000/health`

في وضع التطوير يمكن استخدام OTP الذي يرجعه API في `devCode`. لا تستخدم ذلك في الإنتاج.

## تطبيقات Flutter
داخل كل من `apps/passenger_app` و`apps/driver_app`:
- نفّذ `flutter create --platforms android,ios .` إذا لم تكن مجلدات Android/iOS موجودة.
- نفّذ `flutter pub get`.
- أضف ملفات Firebase الخاصة بالتطبيق إلى Android وiOS.
- أضف مفتاح Google Maps إلى Android وiOS.
- شغّل التطبيق مع:
  `flutter run --dart-define=API_URL=https://api.your-domain.com`

## الإنتاج الحقيقي
هناك عناصر خارج الكود لا يمكن إنشاؤها تلقائيًا من داخل ملف ZIP: حساب Google Cloud ومفتاح Routes/Maps، مشروع Firebase وملفات الاعتماد، مزود SMS وبياناته، اسم النطاق وشهادة HTTPS، حسابات متاجر Google Play/App Store، واستيفاء متطلبات الترخيص والتنظيم المحلية لخدمة النقل.

لا تضع أي مفتاح سري داخل Flutter أو Git.
