import React, {useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:3000";

function App(){
  const [token,setToken]=useState(localStorage.getItem("adminToken")||"");
  const [username,setUsername]=useState(""); const [password,setPassword]=useState("");
  const [stats,setStats]=useState(null), [drivers,setDrivers]=useState([]), [trips,setTrips]=useState([]), [pricing,setPricing]=useState([]), [documents,setDocuments]=useState([]), [tickets,setTickets]=useState([]), [error,setError]=useState("");
  async function login(){const r=await fetch(`${API}/admin/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username,password})});const d=await r.json();if(!r.ok){setError(d.error||"فشل الدخول");return}localStorage.setItem("adminToken",d.token);setToken(d.token);}
  async function load(){if(!token)return;const h={Authorization:`Bearer ${token}`};try{const [s,d,t,p,docs,tks]=await Promise.all([fetch(`${API}/admin/stats`,{headers:h}),fetch(`${API}/admin/drivers`,{headers:h}),fetch(`${API}/admin/trips`,{headers:h}),fetch(`${API}/admin/pricing`,{headers:h}),fetch(`${API}/admin/documents`,{headers:h}),fetch(`${API}/admin/tickets`,{headers:h})]);if(!s.ok)throw new Error(await s.text());setStats(await s.json());setDrivers(await d.json());setTrips(await t.json());setPricing(await p.json());setDocuments(await docs.json());setTickets(await tks.json());setError("")}catch(e){setError(e.message)}}
  useEffect(()=>{load()},[token]);
  if(!token)return <div className="login" dir="rtl"><h1>مشوارك — لوحة الإدارة</h1><input placeholder="اسم المستخدم" value={username} onChange={e=>setUsername(e.target.value)}/><input type="password" placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)}/><button onClick={login}>دخول</button>{error&&<p className="error">{error}</p>}</div>;
  return <main dir="rtl"><header><h1>لوحة تحكم مشوارك</h1><div><button onClick={load}>تحديث</button> <button onClick={()=>{localStorage.removeItem("adminToken");setToken("")}}>خروج</button></div></header>{error&&<div className="error">{error}</div>}<section className="cards"><Card t="المستخدمون" v={stats?.users??"—"}/><Card t="السائقون" v={stats?.drivers??"—"}/><Card t="الرحلات" v={stats?.trips??"—"}/><Card t="إيراد الرحلات" v={stats?.completedRevenue??"—"}/></section><section><h2>السائقون</h2><Table heads={["الهاتف","الحالة","الموقع"]} rows={drivers.map(d=>[d.phone,d.status,`${d.current_lat??"—"}, ${d.current_lng??"—"}`])}/></section><section><h2>آخر الرحلات</h2><Table heads={["ID","الحالة","الأجرة","الإنشاء"]} rows={trips.map(t=>[t.id,t.status,t.final_fare??t.estimated_fare??"—",new Date(t.created_at).toLocaleString()])}/></section><section><h2>الأسعار</h2><Table heads={["المدينة","أساسي","/كم","/دقيقة","رسوم"]} rows={pricing.map(x=>[x.city_name||"عام",x.base_fare,x.per_km,x.per_minute,x.service_fee])}/></section><section><h2>مستندات السائقين</h2><Table heads={["الهاتف","النوع","الحالة"]} rows={documents.map(x=>[x.phone,x.document_type,x.status])}/></section><section><h2>الدعم</h2><Table heads={["الهاتف","الموضوع","الحالة","الرد"]} rows={tickets.map(x=>[x.phone||"—",x.subject,x.status,x.admin_reply||"—"])}/></section></main>
}
function Card({t,v}){return <div className="card"><small>{t}</small><strong>{v}</strong></div>}
function Table({heads,rows}){return <table><thead><tr>{heads.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i}>{r.map((x,j)=><td key={j}>{String(x)}</td>)}</tr>)}</tbody></table>}
createRoot(document.getElementById("root")).render(<App/>);
