import 'dart:convert';
import 'package:http/http.dart' as http;

class MatchingService {
  final String baseUrl;
  final String token;

  MatchingService({required this.baseUrl, required this.token});

  Future<Map<String, dynamic>> matchDriver(String tripId) async {
    final r = await http.post(
      Uri.parse('$baseUrl/trips/$tripId/match-driver'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Driver matching failed: ${r.body}');
    }
    return jsonDecode(r.body);
  }
}
