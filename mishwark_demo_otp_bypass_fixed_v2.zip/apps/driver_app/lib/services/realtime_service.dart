import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

class RealtimeService {
  final String wsBaseUrl;
  WebSocketChannel? _channel;

  RealtimeService(this.wsBaseUrl);

  Stream<Map<String, dynamic>> connect({
    required String tripId,
    required String role,
  }) {
    final uri = Uri.parse(
      '$wsBaseUrl/ws?tripId=${Uri.encodeComponent(tripId)}&role=${Uri.encodeComponent(role)}',
    );
    _channel = WebSocketChannel.connect(uri);
    return _channel!.stream.map((event) {
      return jsonDecode(event as String) as Map<String, dynamic>;
    });
  }

  void sendDriverLocation({
    required double lat,
    required double lng,
  }) {
    _channel?.sink.add(jsonEncode({
      'type': 'driver_location',
      'lat': lat,
      'lng': lng,
    }));
  }

  void sendTripStatus(String status) {
    _channel?.sink.add(jsonEncode({
      'type': 'trip_status',
      'status': status,
    }));
  }

  Future<void> close() async {
    await _channel?.sink.close();
    _channel = null;
  }
}
