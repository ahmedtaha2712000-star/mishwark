import 'dart:convert';
import 'package:http/http.dart' as http;

class TripActionsService {
  final String baseUrl;
  final String token;
  TripActionsService({required this.baseUrl, required this.token});

  Future<Map<String,dynamic>> action(String tripId,String action) async {
    final r=await http.post(
      Uri.parse('$baseUrl/trips/$tripId/action'),
      headers:{'Authorization':'Bearer $token','Content-Type':'application/json'},
      body:jsonEncode({'action':action}),
    );
    if(r.statusCode<200||r.statusCode>=300) throw Exception(r.body);
    return jsonDecode(r.body);
  }

  Future<Map<String,dynamic>> cashPayment(String tripId) async {
    final r=await http.post(
      Uri.parse('$baseUrl/trips/$tripId/cash-payment'),
      headers:{'Authorization':'Bearer $token'},
    );
    if(r.statusCode<200||r.statusCode>=300) throw Exception(r.body);
    return jsonDecode(r.body);
  }

  Future<Map<String,dynamic>> rate(String tripId,int rating,{String? comment}) async {
    final r=await http.post(
      Uri.parse('$baseUrl/trips/$tripId/rating'),
      headers:{'Authorization':'Bearer $token','Content-Type':'application/json'},
      body:jsonEncode({'rating':rating,'comment':comment}),
    );
    if(r.statusCode<200||r.statusCode>=300) throw Exception(r.body);
    return jsonDecode(r.body);
  }
}
