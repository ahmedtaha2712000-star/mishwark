import 'dart:convert';
import 'package:http/http.dart' as http;

class TripFlowService {
  final String baseUrl;
  final String token;

  TripFlowService({required this.baseUrl, required this.token});

  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $token',
  };

  Future<Map<String, dynamic>> setStatus(
      String tripId, String status) async {
    final r = await http.post(
      Uri.parse('$baseUrl/trips/$tripId/status-flow'),
      headers: _headers,
      body: jsonEncode({'status': status}),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Trip status failed: ${r.body}');
    }
    return jsonDecode(r.body);
  }

  Future<Map<String, dynamic>> payCash(
      String tripId, double finalFare) async {
    final r = await http.post(
      Uri.parse('$baseUrl/trips/$tripId/payment/cash'),
      headers: _headers,
      body: jsonEncode({'finalFare': finalFare}),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Cash payment failed: ${r.body}');
    }
    return jsonDecode(r.body);
  }

  Future<Map<String, dynamic>> rate(
      String tripId, int stars, {String? comment}) async {
    final r = await http.post(
      Uri.parse('$baseUrl/trips/$tripId/rating'),
      headers: _headers,
      body: jsonEncode({'stars': stars, 'comment': comment}),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('Rating failed: ${r.body}');
    }
    return jsonDecode(r.body);
  }
}
