import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapPickerScreen extends StatefulWidget {
  final LatLng? initialPickup;
  final LatLng? initialDestination;

  const MapPickerScreen({
    super.key,
    this.initialPickup,
    this.initialDestination,
  });

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  GoogleMapController? _controller;
  LatLng? _destination;

  static const LatLng _defaultCenter = LatLng(30.0444, 31.2357); // Cairo

  @override
  void initState() {
    super.initState();
    _destination = widget.initialDestination;
  }

  void _selectDestination(LatLng point) {
    setState(() => _destination = point);
  }

  @override
  Widget build(BuildContext context) {
    final pickup = widget.initialPickup ?? _defaultCenter;

    final markers = <Marker>{
      Marker(
        markerId: const MarkerId('pickup'),
        position: pickup,
        infoWindow: const InfoWindow(title: 'نقطة الانطلاق'),
      ),
      if (_destination != null)
        Marker(
          markerId: const MarkerId('destination'),
          position: _destination!,
          infoWindow: const InfoWindow(title: 'الوجهة'),
        ),
    };

    return Scaffold(
      appBar: AppBar(title: const Text('اختيار الوجهة')),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: pickup,
              zoom: 14,
            ),
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: false,
            markers: markers,
            onMapCreated: (controller) => _controller = controller,
            onTap: _selectDestination,
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 18,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      _destination == null
                          ? 'اضغط على الخريطة لاختيار الوجهة'
                          : 'تم اختيار الوجهة',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 10),
                    FilledButton(
                      onPressed: _destination == null
                          ? null
                          : () => Navigator.pop(context, _destination),
                      child: const Text('تأكيد الوجهة'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
