import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  final String baseUrl;
  AuthService(this.baseUrl);

  Future<Map<String, dynamic>> requestOtp(String phone) async {
    final r = await http.post(
      Uri.parse('$baseUrl/auth/request-otp'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'phone': phone}),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('OTP request failed: ${r.body}');
    }
    return jsonDecode(r.body);
  }

  Future<Map<String, dynamic>> verifyOtp({
    required String phone,
    required String code,
    required String role,
  }) async {
    final r = await http.post(
      Uri.parse('$baseUrl/auth/verify-otp'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'phone': phone,
        'code': code,
        'role': role,
      }),
    );
    if (r.statusCode < 200 || r.statusCode >= 300) {
      throw Exception('OTP verification failed: ${r.body}');
    }

    final data = jsonDecode(r.body) as Map<String, dynamic>;
    final token = data['token'];
    if (token is String) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('auth_token', token);
    }
    return data;
  }

  Future<String?> token() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
  }
}
