import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:http/http.dart' as http;
class PushNotificationService {
  final String baseUrl; final String token;
  PushNotificationService({required this.baseUrl,required this.token});
  Future<void> init() async {
    try {
      await Firebase.initializeApp();
      await FirebaseMessaging.instance.requestPermission(alert:true,badge:true,sound:true);
      final t=await FirebaseMessaging.instance.getToken();
      if(t!=null) await http.post(Uri.parse('$baseUrl/devices/token'),headers:{'Authorization':'Bearer $token','Content-Type':'application/json'},body:'{"token":"$t","platform":"flutter"}');
    } catch (_) {}
  }
}
