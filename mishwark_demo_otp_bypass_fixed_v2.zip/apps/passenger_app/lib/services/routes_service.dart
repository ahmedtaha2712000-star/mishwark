import 'dart:convert';
import 'package:http/http.dart' as http;

class RouteEstimate {
  final int? distanceMeters;
  final int? durationSeconds;
  final String? polyline;
  final double? estimatedFare;
  final String currency;

  RouteEstimate({
    required this.distanceMeters,
    required this.durationSeconds,
    required this.polyline,
    required this.estimatedFare,
    required this.currency,
  });

  factory RouteEstimate.fromJson(Map<String, dynamic> json) {
    return RouteEstimate(
      distanceMeters: (json['distanceMeters'] as num?)?.toInt(),
      durationSeconds: (json['durationSeconds'] as num?)?.toInt(),
      polyline: json['polyline'] as String?,
      estimatedFare: (json['estimatedFare'] as num?)?.toDouble(),
      currency: (json['currency'] as String?) ?? 'EGP',
    );
  }
}

class RoutesService {
  final String baseUrl;
  RoutesService(this.baseUrl);

  Future<RouteEstimate> estimate({
    required double originLat,
    required double originLng,
    required double destinationLat,
    required double destinationLng,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/routes/estimate'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'origin': {'lat': originLat, 'lng': originLng},
        'destination': {'lat': destinationLat, 'lng': destinationLng},
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Route estimate failed: ${response.body}');
    }

    return RouteEstimate.fromJson(jsonDecode(response.body));
  }
}
