import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/realtime_service.dart';

class LiveDriverMap extends StatefulWidget {
  final String tripId;
  final String wsBaseUrl;
  final LatLng initialCenter;

  const LiveDriverMap({
    super.key,
    required this.tripId,
    required this.wsBaseUrl,
    required this.initialCenter,
  });

  @override
  State<LiveDriverMap> createState() => _LiveDriverMapState();
}

class _LiveDriverMapState extends State<LiveDriverMap> {
  final RealtimeService _realtime = RealtimeService('');
  StreamSubscription<Map<String, dynamic>>? _sub;
  LatLng? _driverPosition;

  @override
  void initState() {
    super.initState();
    final service = RealtimeService(widget.wsBaseUrl);
    _sub = service.connect(
      tripId: widget.tripId,
      role: 'passenger',
    ).listen((event) {
      if (event['type'] == 'driver_location') {
        final lat = (event['lat'] as num).toDouble();
        final lng = (event['lng'] as num).toDouble();
        setState(() => _driverPosition = LatLng(lat, lng));
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>{
      if (_driverPosition != null)
        Marker(
          markerId: const MarkerId('live-driver'),
          position: _driverPosition!,
          infoWindow: const InfoWindow(title: 'السائق'),
        ),
    };

    return GoogleMap(
      initialCameraPosition: CameraPosition(
        target: widget.initialCenter,
        zoom: 14,
      ),
      markers: markers,
      myLocationEnabled: true,
      myLocationButtonEnabled: true,
    );
  }
}
