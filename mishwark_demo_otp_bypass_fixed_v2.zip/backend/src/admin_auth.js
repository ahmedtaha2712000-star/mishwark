const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const {pool}=require('./db');
async function ensureAdmin(){
 const u=process.env.ADMIN_USERNAME, p=process.env.ADMIN_PASSWORD;
 if(!u||!p)return;
 const hash=await bcrypt.hash(p,12);
 await pool.query(`INSERT INTO admin_users(username,password_hash) VALUES($1,$2) ON CONFLICT(username) DO NOTHING`,[u,hash]);
}
async function loginAdmin(username,password){
 const {rows}=await pool.query(`SELECT * FROM admin_users WHERE username=$1 AND active=true`,[username]);
 if(!rows[0]||!(await bcrypt.compare(password,rows[0].password_hash)))throw new Error('Invalid admin credentials');
 const token=jwt.sign({sub:rows[0].id,role:'ADMIN',username:rows[0].username},process.env.JWT_SECRET,{expiresIn:process.env.ADMIN_JWT_EXPIRES_IN||'8h'});
 return {token};
}
module.exports={ensureAdmin,loginAdmin};
