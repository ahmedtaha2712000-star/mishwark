const express = require("express");
const router = express.Router();
const { pool } = require("./db");
const { requireAuth, requireRole } = require("./auth");

router.use(requireAuth, requireRole("ADMIN"));

router.get("/stats", async (_req, res) => {
  try {
    const [users, drivers, trips, revenue] = await Promise.all([
      pool.query(`SELECT count(*)::int AS count FROM users`),
      pool.query(`SELECT count(*)::int AS count FROM drivers`),
      pool.query(`SELECT count(*)::int AS count FROM trips`),
      pool.query(`
        SELECT COALESCE(SUM(final_fare),0)::numeric AS total
        FROM trips WHERE status='COMPLETED'
      `)
    ]);
    res.json({
      users: users.rows[0].count,
      drivers: drivers.rows[0].count,
      trips: trips.rows[0].count,
      completedRevenue: revenue.rows[0].total
    });
  } catch (e) {
    res.status(500).json({error:e.message});
  }
});

router.get("/trips", async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit || 50), 200);
    const { rows } = await pool.query(`
      SELECT t.*, 
             pu.phone AS passenger_phone,
             du.phone AS driver_phone
      FROM trips t
      LEFT JOIN users pu ON pu.id=t.passenger_id
      LEFT JOIN drivers d ON d.id=t.driver_id
      LEFT JOIN users du ON du.id=d.user_id
      ORDER BY t.created_at DESC
      LIMIT $1
    `, [limit]);
    res.json(rows);
  } catch (e) {
    res.status(500).json({error:e.message});
  }
});

router.get("/drivers", async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT d.*, u.phone
      FROM drivers d
      JOIN users u ON u.id=d.user_id
      ORDER BY d.updated_at DESC
    `);
    res.json(rows);
  } catch (e) {
    res.status(500).json({error:e.message});
  }
});

router.get("/users", async (_req, res) => {
  try {
    const { rows } = await pool.query(`
      SELECT id, phone, role, created_at
      FROM users ORDER BY created_at DESC
    `);
    res.json(rows);
  } catch (e) {
    res.status(500).json({error:e.message});
  }
});

router.patch("/drivers/:id/status", async (req, res) => {
  try {
    const allowed = ["ONLINE", "OFFLINE", "BUSY", "SUSPENDED"];
    if (!allowed.includes(req.body.status))
      return res.status(400).json({error:"Invalid status"});
    const { rows } = await pool.query(
      `UPDATE drivers SET status=$2, updated_at=now()
       WHERE id=$1 RETURNING *`,
      [req.params.id, req.body.status]
    );
    if (!rows[0]) return res.status(404).json({error:"Driver not found"});
    res.json(rows[0]);
  } catch (e) {
    res.status(500).json({error:e.message});
  }
});

module.exports = router;
