const express=require('express');
const router=express.Router();
const {pool}=require('./db');
const {requireAuth}=require('./auth');
const {transitionTrip,setPaymentCompleted,createRating}=require('./trip_flow_repository');
const {sendPush}=require('./notifications');
router.use(requireAuth);

async function tripForUser(id){
  const {rows}=await pool.query(`SELECT t.*,d.user_id AS driver_user_id FROM trips t LEFT JOIN drivers d ON d.id=t.driver_id WHERE t.id=$1`,[id]);
  return rows[0]||null;
}

router.post('/:id/action',async(req,res)=>{
  try{
    const trip=await tripForUser(req.params.id); if(!trip)return res.status(404).json({error:'Trip not found'});
    const action=String(req.body?.action||'');
    const passengerActions={CANCEL:'CANCELLED'};
    const driverActions={ACCEPT:'DRIVER_ACCEPTED',ARRIVING:'DRIVER_ARRIVING',ARRIVED:'DRIVER_ARRIVED',START:'TRIP_STARTED',COMPLETE:'TRIP_COMPLETED'};
    let next=null;
    if(trip.passenger_id===req.user.sub) next=passengerActions[action]||null;
    if(trip.driver_user_id===req.user.sub) next=driverActions[action]||null;
    if(!next)return res.status(403).json({error:'Action not allowed'});
    const updated=await transitionTrip(trip.id,next,req.user.sub);
    const messages={
      DRIVER_ACCEPTED:['تم قبول الرحلة','السائق قبل رحلتك'],DRIVER_ARRIVING:['السائق في الطريق','السائق متجه إليك الآن'],
      DRIVER_ARRIVED:['السائق وصل','السائق وصل إلى نقطة الالتقاط'],TRIP_STARTED:['بدأت الرحلة','رحلتك بدأت'],
      TRIP_COMPLETED:['انتهت الرحلة','يرجى إتمام الدفع النقدي والتقييم'],CANCELLED:['تم إلغاء الرحلة','تم إلغاء الرحلة']
    };
    if(messages[next]&&trip.passenger_id) await sendPush({userId:trip.passenger_id,title:messages[next][0],body:messages[next][1],data:{tripId:String(trip.id)}});
    res.json(updated);
  }catch(e){res.status(400).json({error:e.message});}
});

router.post('/:id/cash-payment',async(req,res)=>{
  try{
    const trip=await tripForUser(req.params.id);
    if(!trip||trip.passenger_id!==req.user.sub)return res.status(403).json({error:'Forbidden'});
    const updated=await setPaymentCompleted(trip.id,req.body?.finalFare,req.user.sub);
    if(!updated)return res.status(400).json({error:'Payment not pending'});
    res.json(updated);
  }catch(e){res.status(400).json({error:e.message});}
});

router.post('/:id/rating',async(req,res)=>{
  try{
    const trip=await tripForUser(req.params.id);
    if(!trip||trip.passenger_id!==req.user.sub)return res.status(403).json({error:'Forbidden'});
    const rating=Number(req.body?.rating);
    if(!Number.isInteger(rating)||rating<1||rating>5)return res.status(400).json({error:'rating must be 1..5'});
    res.status(201).json(await createRating({tripId:trip.id,raterId:req.user.sub,stars:rating,comment:req.body?.comment}));
  }catch(e){res.status(400).json({error:e.message});}
});
module.exports=router;
