const {pool}=require('./db');
async function findNearestOnlineDriver(lat,lng,radiusKm=Number(process.env.MATCH_RADIUS_KM||10)){
 const {rows}=await pool.query(`SELECT id,user_id,current_lat,current_lng,(6371*acos(least(1,greatest(-1,cos(radians($1))*cos(radians(current_lat))*cos(radians(current_lng)-radians($2))+sin(radians($1))*sin(radians(current_lat)))))) AS distance_km FROM drivers WHERE status='ONLINE' AND current_lat IS NOT NULL AND current_lng IS NOT NULL ORDER BY distance_km ASC LIMIT 1`,[lat,lng]);
 const d=rows[0]; return !d||Number(d.distance_km)>radiusKm?null:d;
}
async function assignNearestDriver(tripId,pickupLat,pickupLng){
 const client=await pool.connect();
 try{await client.query('BEGIN');
  const d=(await client.query(`SELECT id,user_id,current_lat,current_lng,(6371*acos(least(1,greatest(-1,cos(radians($1))*cos(radians(current_lat))*cos(radians(current_lng)-radians($2))+sin(radians($1))*sin(radians(current_lat)))))) AS distance_km FROM drivers WHERE status='ONLINE' AND current_lat IS NOT NULL AND current_lng IS NOT NULL ORDER BY distance_km ASC LIMIT 1 FOR UPDATE SKIP LOCKED`,[pickupLat,pickupLng])).rows[0];
  if(!d||Number(d.distance_km)>Number(process.env.MATCH_RADIUS_KM||10)){await client.query('ROLLBACK');return null;}
  const t=(await client.query(`UPDATE trips SET driver_id=$2,status='SEARCHING_DRIVER',updated_at=now() WHERE id=$1 AND driver_id IS NULL AND status='SEARCHING_DRIVER' RETURNING *`,[tripId,d.id])).rows[0];
  if(!t){await client.query('ROLLBACK');return null;}
  await client.query(`UPDATE drivers SET status='BUSY',updated_at=now() WHERE id=$1`,[d.id]);
  await client.query(`INSERT INTO trip_status_history(trip_id,status) VALUES($1,'SEARCHING_DRIVER') ON CONFLICT DO NOTHING`,[tripId]);
  await client.query('COMMIT');return t;
 }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}
module.exports={findNearestOnlineDriver,assignNearestDriver};
