const admin=require('firebase-admin');
const {pool}=require('./db');
let initialized=false;
function init(){
  if(initialized||!process.env.FIREBASE_PROJECT_ID||!process.env.FIREBASE_CLIENT_EMAIL||!process.env.FIREBASE_PRIVATE_KEY)return;
  admin.initializeApp({credential:admin.credential.cert({projectId:process.env.FIREBASE_PROJECT_ID,clientEmail:process.env.FIREBASE_CLIENT_EMAIL,privateKey:process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g,'\n')})});initialized=true;
}
async function sendPush({userId,title,body,data={}}){
  init();
  const {rows}=await pool.query(`SELECT token FROM device_tokens WHERE user_id=$1 AND active=true`,[userId]);
  if(!rows.length)return {delivered:false,reason:'no_device_token'};
  if(!initialized){console.log('[PUSH-DEV]',{userId,title,body,data});return {delivered:false,mode:'development-log'};}
  const response=await admin.messaging().sendEachForMulticast({tokens:rows.map(x=>x.token),notification:{title,body},data:Object.fromEntries(Object.entries(data).map(([k,v])=>[k,String(v)]))});
  const invalid=[]; response.responses.forEach((r,i)=>{if(!r.success&&['messaging/registration-token-not-registered','messaging/invalid-registration-token'].includes(r.error?.code))invalid.push(rows[i].token);});
  if(invalid.length)await pool.query(`UPDATE device_tokens SET active=false,updated_at=now() WHERE token=ANY($1::text[])`,[invalid]);
  return {delivered:response.successCount>0,successCount:response.successCount,failureCount:response.failureCount};
}
module.exports={sendPush};
