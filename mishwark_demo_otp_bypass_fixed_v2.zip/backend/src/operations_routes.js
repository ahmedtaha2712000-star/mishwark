const express=require("express");
const router=express.Router();
const {pool}=require("./db");
const {requireAuth,requireRole}=require("./auth");
router.use(requireAuth,requireRole("ADMIN"));

router.get("/cities",async(_req,res)=>{
  try{const {rows}=await pool.query(`SELECT * FROM cities ORDER BY name`);res.json(rows)}
  catch(e){res.status(500).json({error:e.message})}
});
router.post("/cities",async(req,res)=>{
  try{const {name}=req.body;if(!name)return res.status(400).json({error:"name required"});
    const {rows}=await pool.query(`INSERT INTO cities(name) VALUES($1) RETURNING *`,[name]);res.status(201).json(rows[0])
  }catch(e){res.status(500).json({error:e.message})}
});
router.get("/areas",async(_req,res)=>{
  try{const {rows}=await pool.query(`SELECT a.*,c.name city_name FROM areas a LEFT JOIN cities c ON c.id=a.city_id ORDER BY c.name,a.name`);res.json(rows)}
  catch(e){res.status(500).json({error:e.message})}
});
router.post("/areas",async(req,res)=>{
  try{const {cityId,name}=req.body;if(!cityId||!name)return res.status(400).json({error:"cityId and name required"});
    const {rows}=await pool.query(`INSERT INTO areas(city_id,name) VALUES($1,$2) RETURNING *`,[cityId,name]);res.status(201).json(rows[0])
  }catch(e){res.status(500).json({error:e.message})}
});
router.get("/pricing",async(_req,res)=>{
  try{const {rows}=await pool.query(`SELECT p.*,c.name city_name FROM pricing_rules p LEFT JOIN cities c ON c.id=p.city_id ORDER BY c.name`);res.json(rows)}
  catch(e){res.status(500).json({error:e.message})}
});
router.post("/pricing",async(req,res)=>{
  try{
    const {cityId,baseFare,perKm,perMinute,serviceFee}=req.body;
    const {rows}=await pool.query(
      `INSERT INTO pricing_rules(city_id,base_fare,per_km,per_minute,service_fee)
       VALUES($1,$2,$3,$4,$5) RETURNING *`,
      [cityId,baseFare,perKm,perMinute,serviceFee]);
    res.status(201).json(rows[0]);
  }catch(e){res.status(500).json({error:e.message})}
});
router.get("/documents",async(_req,res)=>{
  try{const {rows}=await pool.query(`
    SELECT d.*,u.phone FROM driver_documents d
    JOIN drivers dr ON dr.id=d.driver_id JOIN users u ON u.id=dr.user_id
    ORDER BY d.created_at DESC`);res.json(rows)}
  catch(e){res.status(500).json({error:e.message})}
});
router.patch("/documents/:id",async(req,res)=>{
  try{
    const allowed=["APPROVED","REJECTED","PENDING"];
    if(!allowed.includes(req.body.status))return res.status(400).json({error:"Invalid status"});
    const {rows}=await pool.query(
      `UPDATE driver_documents SET status=$2,rejection_reason=$3,updated_at=now()
       WHERE id=$1 RETURNING *`,[req.params.id,req.body.status,req.body.rejectionReason||null]);
    if(!rows[0])return res.status(404).json({error:"Document not found"});
    res.json(rows[0]);
  }catch(e){res.status(500).json({error:e.message})}
});
router.get("/tickets",async(_req,res)=>{
  try{const {rows}=await pool.query(`
    SELECT s.*,u.phone FROM support_tickets s
    LEFT JOIN users u ON u.id=s.user_id ORDER BY s.created_at DESC`);res.json(rows)}
  catch(e){res.status(500).json({error:e.message})}
});
router.patch("/tickets/:id",async(req,res)=>{
  try{
    const allowed=["OPEN","IN_PROGRESS","RESOLVED","CLOSED"];
    if(!allowed.includes(req.body.status))return res.status(400).json({error:"Invalid status"});
    const {rows}=await pool.query(
      `UPDATE support_tickets SET status=$2,admin_reply=$3,updated_at=now()
       WHERE id=$1 RETURNING *`,[req.params.id,req.body.status,req.body.adminReply||null]);
    if(!rows[0])return res.status(404).json({error:"Ticket not found"});
    res.json(rows[0]);
  }catch(e){res.status(500).json({error:e.message})}
});
module.exports=router;
