function calculateFare({ distanceMeters, durationSeconds }) {
  const base = Number(process.env.FARE_BASE || 20);
  const perKm = Number(process.env.FARE_PER_KM || 8);
  const perMinute = Number(process.env.FARE_PER_MINUTE || 1.5);
  const serviceFee = Number(process.env.FARE_SERVICE_FEE || 0);

  const km = Math.max(0, Number(distanceMeters || 0)) / 1000;
  const minutes = Math.max(0, Number(durationSeconds || 0)) / 60;

  return Math.max(
    0,
    Math.round((base + km * perKm + minutes * perMinute + serviceFee) * 100) / 100
  );
}

module.exports = { calculateFare };
