const WebSocket=require('ws');
const jwt=require('jsonwebtoken');
const {pool}=require('./db');
function attachRealtime(server){
 const wss=new WebSocket.Server({server,path:'/ws'}); const clients=new Map();
 function broadcast(id,p){for(const ws of clients.get(String(id))||[]){if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(p));}}
 wss.on('connection',async(ws,req)=>{
  try{
   const u=new URL(req.url,'http://localhost'); const tripId=u.searchParams.get('tripId'); const token=u.searchParams.get('token');
   if(!tripId||!token)throw new Error('missing auth'); const user=jwt.verify(token,process.env.JWT_SECRET);
   const t=(await pool.query(`SELECT t.passenger_id,d.user_id AS driver_user_id FROM trips t LEFT JOIN drivers d ON d.id=t.driver_id WHERE t.id=$1`,[tripId])).rows[0];
   if(!t||![t.passenger_id,t.driver_user_id].includes(user.sub))throw new Error('forbidden');
   const role=user.role==='DRIVER'?'driver':'passenger'; const key=String(tripId); if(!clients.has(key))clients.set(key,new Set());clients.get(key).add(ws);
   ws.send(JSON.stringify({type:'connected',tripId:key,role}));
   ws.on('message',async raw=>{try{const d=JSON.parse(raw.toString());if(role==='driver'&&d.type==='driver_location'){const lat=Number(d.lat),lng=Number(d.lng);if(!Number.isFinite(lat)||!Number.isFinite(lng))return;await pool.query(`UPDATE drivers SET current_lat=$2,current_lng=$3,updated_at=now() WHERE user_id=$1`,[user.sub,lat,lng]);broadcast(key,{type:'driver_location',tripId:key,lat,lng,timestamp:Date.now()});}}catch(_){}});
   ws.on('close',()=>{const set=clients.get(key);if(set){set.delete(ws);if(!set.size)clients.delete(key);}});
  }catch(e){ws.close(1008,e.message);}
 });
 return wss;
}
module.exports={attachRealtime};
