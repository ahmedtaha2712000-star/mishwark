const GOOGLE_ROUTES_URL='https://routes.googleapis.com/directions/v2:computeRoutes';
function fallback(origin,destination){
 const r=6371000, a=Number(origin.lat)*Math.PI/180,b=Number(destination.lat)*Math.PI/180, da=(Number(destination.lat)-Number(origin.lat))*Math.PI/180, dl=(Number(destination.lng)-Number(origin.lng))*Math.PI/180;
 const h=Math.sin(da/2)**2+Math.cos(a)*Math.cos(b)*Math.sin(dl/2)**2; const distance=Math.round(2*r*Math.asin(Math.sqrt(h))); const duration=Math.round(distance/8.3); return {provider:'fallback',distanceMeters:distance,durationSeconds:duration,polyline:null,message:'Configure GOOGLE_ROUTES_API_KEY for road routing'};
}
async function computeRoute({origin,destination}){
 const key=process.env.GOOGLE_ROUTES_API_KEY; if(!key)return fallback(origin,destination);
 const body={origin:{location:{latLng:{latitude:Number(origin.lat),longitude:Number(origin.lng)}}},destination:{location:{latLng:{latitude:Number(destination.lat),longitude:Number(destination.lng)}}},travelMode:'DRIVE',routingPreference:'TRAFFIC_AWARE',computeAlternativeRoutes:false,languageCode:'ar',units:'METRIC'};
 const response=await fetch(GOOGLE_ROUTES_URL,{method:'POST',headers:{'Content-Type':'application/json','X-Goog-Api-Key':key,'X-Goog-FieldMask':'routes.duration,routes.distanceMeters,routes.polyline.encodedPolyline'},body:JSON.stringify(body)});
 if(!response.ok)throw new Error(`Routes API error ${response.status}: ${await response.text()}`);
 const data=await response.json(),route=data.routes?.[0]; if(!route)throw new Error('No route returned');
 return {provider:'google',distanceMeters:route.distanceMeters??0,durationSeconds:Number(String(route.duration||'0s').replace('s',''))||0,polyline:route.polyline?.encodedPolyline??null};
}
module.exports={computeRoute};
