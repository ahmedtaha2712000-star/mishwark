require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const { pool } = require('./db');
const { requestOtp, verifyOtp, requireAuth, requireRole } = require('./auth');
const { computeRoute } = require('./routes');
const { calculateFare } = require('./pricing');
const { attachRealtime } = require('./realtime');
const { assignNearestDriver } = require('./matching');
const { sendPush } = require('./notifications');
const { ensureAdmin, loginAdmin } = require('./admin_auth');
const tripFlowRoutes = require('./end_to_end_routes');
const adminRoutes = require('./admin_routes');
const operationsRoutes = require('./operations_routes');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',').map(s=>s.trim()) : true }));
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit({ windowMs: 60_000, limit: Number(process.env.RATE_LIMIT_PER_MINUTE || 120), standardHeaders: true, legacyHeaders: false }));

app.get('/health', async (_req,res) => {
  try { await pool.query('SELECT 1'); res.json({ok:true, service:'mishwark-api'}); }
  catch (e) { res.status(503).json({ok:false,error:'database_unavailable'}); }
});

app.post('/auth/request-otp', async (req,res)=>{
  try { res.json(await requestOtp(req.body?.phone)); }
  catch(e) { res.status(400).json({error:e.message}); }
});
app.post('/auth/verify-otp', async (req,res)=>{
  try { res.json(await verifyOtp(req.body?.phone, req.body?.code, req.body?.role || 'PASSENGER')); }
  catch(e) { res.status(401).json({error:e.message}); }
});
app.get('/auth/me', requireAuth, (req,res)=>res.json({user:req.user}));
app.post('/admin/login', async (req,res)=>{ try{res.json(await loginAdmin(String(req.body?.username||''),String(req.body?.password||'')));}catch(e){res.status(401).json({error:'Invalid credentials'});} });

app.post('/devices/token', requireAuth, async (req,res)=>{
  const token = String(req.body?.token || '').trim();
  const platform = String(req.body?.platform || 'unknown').toLowerCase();
  if (!token) return res.status(400).json({error:'token is required'});
  await pool.query(`INSERT INTO device_tokens(user_id,token,platform) VALUES($1,$2,$3)
    ON CONFLICT(token) DO UPDATE SET user_id=EXCLUDED.user_id, platform=EXCLUDED.platform, updated_at=now()`,
    [req.user.sub, token, platform]);
  res.json({ok:true});
});

app.post('/drivers/me/online', requireAuth, requireRole('DRIVER'), async (req,res)=>{
  const online = Boolean(req.body?.online);
  const lat = Number(req.body?.lat), lng = Number(req.body?.lng);
  const { rows } = await pool.query(`UPDATE drivers SET status=$2,
    current_lat=COALESCE($3,current_lat), current_lng=COALESCE($4,current_lng), updated_at=now()
    WHERE user_id=$1 RETURNING *`, [req.user.sub, online ? 'ONLINE' : 'OFFLINE', Number.isFinite(lat)?lat:null, Number.isFinite(lng)?lng:null]);
  if (!rows[0]) return res.status(404).json({error:'Driver profile not found'});
  res.json(rows[0]);
});
app.post('/drivers/me/location', requireAuth, requireRole('DRIVER'), async (req,res)=>{
  const lat=Number(req.body?.lat), lng=Number(req.body?.lng);
  if(!Number.isFinite(lat)||!Number.isFinite(lng)) return res.status(400).json({error:'Invalid coordinates'});
  const { rows } = await pool.query(`UPDATE drivers SET current_lat=$2,current_lng=$3,updated_at=now()
    WHERE user_id=$1 RETURNING id,current_lat,current_lng,status`,[req.user.sub,lat,lng]);
  if(!rows[0]) return res.status(404).json({error:'Driver profile not found'});
  res.json(rows[0]);
});
app.get('/drivers/me/trip', requireAuth, requireRole('DRIVER'), async (req,res)=>{
  const { rows } = await pool.query(`SELECT t.* FROM trips t JOIN drivers d ON d.id=t.driver_id
    WHERE d.user_id=$1 AND t.status IN ('SEARCHING_DRIVER','DRIVER_ACCEPTED','DRIVER_ARRIVING','DRIVER_ARRIVED','TRIP_STARTED')
    ORDER BY t.created_at DESC LIMIT 1`,[req.user.sub]);
  res.json({trip:rows[0]||null});
});

app.post('/routes/estimate', requireAuth, async (req,res)=>{
  try {
    const {origin,destination}=req.body||{};
    if(!origin||!destination) return res.status(400).json({error:'origin and destination are required'});
    const route=await computeRoute({origin,destination});
    res.json({...route,estimatedFare:calculateFare(route),currency:'EGP'});
  } catch(e) { res.status(502).json({error:e.message}); }
});

app.post('/trips', requireAuth, requireRole('PASSENGER'), async (req,res)=>{
  try {
    const p=['pickupLat','pickupLng','destinationLat','destinationLng'].map(k=>Number(req.body?.[k]));
    if(p.some(v=>!Number.isFinite(v))) return res.status(400).json({error:'Invalid coordinates'});
    const [pickupLat,pickupLng,destinationLat,destinationLng]=p;
    const paymentMethod=String(req.body?.paymentMethod||'CASH').toUpperCase();
    if(paymentMethod!=='CASH') return res.status(400).json({error:'Only CASH is enabled'});
    const route=await computeRoute({origin:{lat:pickupLat,lng:pickupLng},destination:{lat:destinationLat,lng:destinationLng}});
    const fare=calculateFare(route);
    const {rows}=await pool.query(`INSERT INTO trips(passenger_id,pickup_lat,pickup_lng,destination_lat,destination_lng,
      distance_meters,duration_seconds,estimated_fare,payment_method,status) VALUES($1,$2,$3,$4,$5,$6,$7,$8,'CASH','SEARCHING_DRIVER') RETURNING *`,
      [req.user.sub,pickupLat,pickupLng,destinationLat,destinationLng,route.distanceMeters,route.durationSeconds,fare]);
    const trip=rows[0];
    await pool.query(`INSERT INTO trip_status_history(trip_id,status,changed_by) VALUES($1,$2,$3)`,[trip.id,trip.status,req.user.sub]);
    const assigned=await assignNearestDriver(trip.id,pickupLat,pickupLng);
    if(assigned?.driver_id){
      await pool.query(`UPDATE drivers SET status='BUSY',updated_at=now() WHERE id=$1`,[assigned.driver_id]);
      const r=await pool.query(`SELECT user_id FROM drivers WHERE id=$1`,[assigned.driver_id]);
      if(r.rows[0]?.user_id) await sendPush({userId:r.rows[0].user_id,title:'رحلة جديدة',body:'لديك طلب رحلة قريب منك',data:{tripId:String(trip.id)}});
    }
    const latest=await pool.query(`SELECT * FROM trips WHERE id=$1`,[trip.id]);
    res.status(201).json(latest.rows[0]);
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get('/trips/:id/live', requireAuth, async (req,res)=>{
  const {rows}=await pool.query(`SELECT t.*, d.current_lat AS driver_lat,d.current_lng AS driver_lng,d.user_id AS driver_user_id
    FROM trips t LEFT JOIN drivers d ON d.id=t.driver_id WHERE t.id=$1`,[req.params.id]);
  const t=rows[0]; if(!t)return res.status(404).json({error:'Trip not found'});
  if(t.passenger_id!==req.user.sub && t.driver_user_id!==req.user.sub && req.user.role!=='ADMIN') return res.status(403).json({error:'Forbidden'});
  res.json(t);
});

app.post('/trips/:id/match-driver', requireAuth, requireRole('PASSENGER'), async (req,res)=>{
  const {rows}=await pool.query(`SELECT * FROM trips WHERE id=$1 AND passenger_id=$2`,[req.params.id,req.user.sub]);
  const trip=rows[0]; if(!trip)return res.status(404).json({error:'Trip not found'});
  const assigned=await assignNearestDriver(trip.id,trip.pickup_lat,trip.pickup_lng);
  if(!assigned)return res.status(404).json({error:'No online driver nearby'});
  const r=await pool.query(`SELECT user_id FROM drivers WHERE id=$1`,[assigned.driver_id]);
  if(r.rows[0]?.user_id) await sendPush({userId:r.rows[0].user_id,title:'رحلة جديدة',body:'لديك طلب رحلة قريب منك',data:{tripId:String(trip.id)}});
  res.json(assigned);
});

app.use('/trips', tripFlowRoutes);
app.use('/admin', adminRoutes);
app.use('/admin', operationsRoutes);

app.use((err,_req,res,_next)=>{ console.error(err); res.status(500).json({error:'internal_server_error'}); });

const httpServer=http.createServer(app);
attachRealtime(httpServer);
const port=Number(process.env.PORT||3000);
ensureAdmin().then(()=>httpServer.listen(port,()=>console.log(`Mishwark API listening on :${port}`))).catch(e=>{console.error(e);process.exit(1);});
