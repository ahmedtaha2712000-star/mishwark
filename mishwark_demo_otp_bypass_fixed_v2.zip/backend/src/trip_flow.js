const ALLOWED = {
  REQUESTED: ["SEARCHING_DRIVER", "CANCELLED"],
  SEARCHING_DRIVER: ["DRIVER_ACCEPTED", "CANCELLED"],
  DRIVER_ACCEPTED: ["DRIVER_ARRIVING", "CANCELLED"],
  DRIVER_ARRIVING: ["DRIVER_ARRIVED", "CANCELLED"],
  DRIVER_ARRIVED: ["TRIP_STARTED", "CANCELLED"],
  TRIP_STARTED: ["TRIP_COMPLETED"],
  TRIP_COMPLETED: ["PAYMENT_PENDING"],
  PAYMENT_PENDING: ["COMPLETED"],
  COMPLETED: [],
  CANCELLED: []
};

function canTransition(from, to) {
  return (ALLOWED[from] || []).includes(to);
}

function assertTransition(from, to) {
  if (!canTransition(from, to)) {
    throw new Error(`Invalid trip transition: ${from} -> ${to}`);
  }
}

module.exports = { ALLOWED, canTransition, assertTransition };
