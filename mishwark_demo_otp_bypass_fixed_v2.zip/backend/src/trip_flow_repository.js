const {pool}=require('./db');
const {assertTransition}=require('./trip_flow');
async function getTrip(id){const {rows}=await pool.query(`SELECT t.*,d.current_lat AS driver_lat,d.current_lng AS driver_lng,d.user_id AS driver_user_id FROM trips t LEFT JOIN drivers d ON d.id=t.driver_id WHERE t.id=$1`,[id]);return rows[0]||null;}
async function transitionTrip(id,nextStatus,changedBy){
  const client=await pool.connect();
  try{
    await client.query('BEGIN');
    const {rows}=await client.query(`SELECT * FROM trips WHERE id=$1 FOR UPDATE`,[id]);
    const current=rows[0]; if(!current)throw new Error('Trip not found');
    assertTransition(current.status,nextStatus);
    const updated=(await client.query(`UPDATE trips SET status=$2,updated_at=now(),completed_at=CASE WHEN $2='TRIP_COMPLETED' THEN now() ELSE completed_at END WHERE id=$1 RETURNING *`,[id,nextStatus])).rows[0];
    await client.query(`INSERT INTO trip_status_history(trip_id,status,changed_by) VALUES($1,$2,$3)`,[id,nextStatus,changedBy||null]);
    if(nextStatus==='CANCELLED' && current.driver_id) await client.query(`UPDATE drivers SET status='ONLINE',updated_at=now() WHERE id=$1 AND status='BUSY'`,[current.driver_id]);
    if(nextStatus==='TRIP_COMPLETED' && current.driver_id) await client.query(`UPDATE drivers SET status='ONLINE',updated_at=now() WHERE id=$1`,[current.driver_id]);
    if(nextStatus==='TRIP_COMPLETED') await client.query(`UPDATE trips SET status='PAYMENT_PENDING',updated_at=now() WHERE id=$1`,[id]);
    await client.query('COMMIT');
    return getTrip(id);
  }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}
async function setPaymentCompleted(id,finalFare,changedBy){
  const client=await pool.connect();
  try{await client.query('BEGIN');
    const {rows}=await client.query(`SELECT * FROM trips WHERE id=$1 FOR UPDATE`,[id]); const t=rows[0]; if(!t||t.status!=='PAYMENT_PENDING')return null;
    const updated=(await client.query(`UPDATE trips SET final_fare=COALESCE($2,estimated_fare),status='COMPLETED',updated_at=now() WHERE id=$1 RETURNING *`,[id,finalFare??null])).rows[0];
    await client.query(`INSERT INTO trip_status_history(trip_id,status,changed_by) VALUES($1,'COMPLETED',$2)`,[id,changedBy||null]);
    await client.query('COMMIT'); return updated;
  }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
}
async function createRating({tripId,raterId,stars,comment}){
  const t=await getTrip(tripId); if(!t||t.status!=='COMPLETED')throw new Error('Trip is not completed');
  const {rows}=await pool.query(`INSERT INTO ratings(trip_id,rater_id,stars,comment) VALUES($1,$2,$3,$4) RETURNING *`,[tripId,raterId,stars,comment||null]); return rows[0];
}
module.exports={getTrip,transitionTrip,setPaymentCompleted,createRating};
