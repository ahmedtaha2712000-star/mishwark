const { pool } = require('./db');

async function createTrip(trip) {
  const q = `
    INSERT INTO trips
      (passenger_id, pickup_lat, pickup_lng, destination_lat, destination_lng,
       distance_meters, duration_seconds, estimated_fare, payment_method, status)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
    RETURNING *`;
  const v = [
    trip.passengerId, trip.pickupLat, trip.pickupLng,
    trip.destinationLat, trip.destinationLng,
    trip.distanceMeters ?? null, trip.durationSeconds ?? null,
    trip.estimatedFare ?? null, trip.paymentMethod || 'CASH',
    trip.status || 'REQUESTED'
  ];
  const { rows } = await pool.query(q, v);
  return rows[0];
}

async function assignDriver(tripId, driverId) {
  const { rows } = await pool.query(
    `UPDATE trips SET driver_id=$2, status='DRIVER_ACCEPTED', updated_at=now()
     WHERE id=$1 RETURNING *`,
    [tripId, driverId]
  );
  return rows[0] || null;
}

async function updateStatus(tripId, status) {
  const { rows } = await pool.query(
    `UPDATE trips SET status=$2, updated_at=now() WHERE id=$1 RETURNING *`,
    [tripId, status]
  );
  return rows[0] || null;
}

async function updateDriverLocation(driverId, lat, lng) {
  const { rows } = await pool.query(
    `UPDATE drivers SET current_lat=$2, current_lng=$3, updated_at=now()
     WHERE id=$1 RETURNING *`,
    [driverId, lat, lng]
  );
  return rows[0] || null;
}

module.exports = { createTrip, assignDriver, updateStatus, updateDriverLocation };
