#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for app in passenger_app driver_app; do
  cd "$ROOT/apps/$app"
  if [ ! -d android ] || [ ! -d ios ]; then
    flutter create --platforms android,ios .
  fi
  flutter pub get
done
