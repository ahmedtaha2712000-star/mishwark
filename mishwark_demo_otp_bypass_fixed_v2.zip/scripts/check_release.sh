#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../backend"
npm install
npm run check
printf '\nBackend syntax check passed.\n'
